﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W4Milestone2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // test driver method
        private void button1_Click(object sender, EventArgs e)
        {
            InventoryItem invItem = new InventoryItem();
            invItem.print();

            DateTime dateTime = System.DateTime.Now;
            InventoryItem invItemOverload = new InventoryItem(1, "Socket Wrench", 5.00m, 3, dateTime);
            invItemOverload.print();

            Console.WriteLine("InventoryItem Testing Finished\n" + "Begin InventoryManager tests");

            InventoryManager inventory = new InventoryManager();
            inventory.addItem(invItem);
            inventory.printAll();
            Console.WriteLine("--item added, now to remove--");
            inventory.removeItem(invItem);
            inventory.printAll();
            Console.WriteLine("--restock--");
            inventory.restock(2, invItem);
            Console.WriteLine("--current inventory--");
            inventory.printAll();

            InventoryItem item = new InventoryItem(2, "Sock", 23, 50, dateTime);
            InventoryItem result = new InventoryItem();
            inventory.addItem(item);
            inventory.search("Sock");
            inventory.search(50);
        }
    }
}