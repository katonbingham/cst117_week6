﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace W4Milestone2
{
    class InventoryManager
    {
        // may make this a class in later assingment
        List<InventoryItem> inventory = new List<InventoryItem>();

        // default constructor
        public InventoryManager()
        {
            // probably do nothing upon construction?
            // assume it will wait for user to generate data
        }

        public void addItem(int itemID, string name, decimal price, double weightLbs, DateTime dateAdded)
        {
            InventoryItem item = new InventoryItem(itemID, name, price, weightLbs, dateAdded);
            inventory.Add(item);
        }

        public void addItem(InventoryItem item) { inventory.Add(item); }
        public void removeItem(InventoryItem item) { inventory.Remove(item); }

        public void restock(int quantity, InventoryItem item)
        {
            for (int i = 0; i < quantity; i++)
            {
                addItem(item);
            }
        }
        
        // several overloaded search functions for type of search query
        public void search(string name)
        {
            InventoryItem result = new InventoryItem();
            result = inventory.Find(x => x.Name == name);
            if (result == null)
            {
                Console.WriteLine("Item Not found");
            }
            else result.print();
        }

        public void search(decimal price)
        {
            // works, no null handling though
            InventoryItem result = new InventoryItem();
            result = inventory.Find(x => x.Price == price);
            if (result == null)
            {
                Console.WriteLine("Item Not found");
            }
            else result.print();
        }

        // technically works
        public void printAll()
        {
            Console.WriteLine("Inventory:");
            foreach (var item in inventory)
            {
                item.print();
            }

        }
    }
}
