﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/* By Katon Bingham
 * 5/31/18
 * cs117
 * all following work is my own
 */
namespace W6ProgrammingProject4
{
    public partial class Form1 : Form
    {
        int matchStatus = 0;
        Random r = new Random();
        int[,] board = new int[3, 3];

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // run the simulation once
            populate();
            display();
            matchStatus = checkWin();
        }

        /*Checks the boardstate and compares against current win conditions*/
        private int checkWin()
        {
            #region horizontal win condition
            if (board[0, 0] == board[0, 1] && board[0, 1] == board[0, 2])
            {
                if (board[0, 0] == 0) { return 1; }
                if (board[0, 0] == 1) { return 2; }
            }
            else if (board[1, 0] == board[1, 1] && board[1, 1] == board[1, 2])
            {
                if (board[1, 0] == 0) { return 1; }
                if (board[1, 0] == 1) { return 2; }
            }
            else if (board[2, 0] == board[2, 1] && board[2, 1] == board[2, 2])
            {
                if (board[2, 0] == 0) { return 1; }
                if (board[2, 0] == 1) { return 2; }
            }
            #endregion
            #region vertical win condition
            else if (board[0, 0] == board[1, 0] && board[1, 0] == board[2, 0])
            {
                if (board[0, 0] == 0) { return 1; }
                if (board[0, 0] == 1) { return 2; }
            }
            else if (board[0, 1] == board[1, 1] && board[1, 1] == board[2, 1])
            {
                if (board[0, 1] == 0) { return 1; }
                if (board[0, 1] == 1) { return 2; }
            }
            else if (board[0, 2] == board[1, 2] && board[1, 2] == board[2, 2])
            {
                if (board[0, 2] == 0) { return 1; }
                if (board[0, 2] == 1) { return 2; }
            }
            #endregion
            #region diagonal win condition
            else if (board[0, 0] == board[1, 1] && board[1, 1] == board[2, 2])
            {
                if (board[0, 0] == 0) { return 1; }
                if (board[0, 0] == 1) { return 2; }
            }
            else if (board[0, 2] == board[1, 1] && board[1, 1] == board[2, 0])
            {
                if (board[0, 2] == 0) { return 1; }
                if (board[0, 2] == 1) { return 2; }
            }
            #endregion
           
            return 0;
        }

        /*iterate through multi-d array, randomly fill with 0 or 1*/ 
        private void populate()
        {
            for (int row = 0; row < 3; row++)
            {
                for (int column = 0; column < 3; column++)
                {
                    board[row, column] = r.Next(0, 2);
                }
            }
        }

        /*Displays the boardstate in X's and O'*/
        private void display()
        {
            #region boardstate to label.text
            if (board[0, 0] == 1) { label1.Text = "X"; } else { label1.Text = "O"; }
            if (board[0, 1] == 1) { label2.Text = "X"; } else { label2.Text = "O"; }
            if (board[0, 2] == 1) { label3.Text = "X"; } else { label3.Text = "O"; }

            if (board[1, 0] == 1) { label4.Text = "X"; } else { label4.Text = "O"; }
            if (board[1, 1] == 1) { label5.Text = "X"; } else { label5.Text = "O"; }
            if (board[1, 2] == 1) { label6.Text = "X"; } else { label6.Text = "O"; }

            if (board[2, 0] == 1) { label7.Text = "X"; } else { label7.Text = "O"; }
            if (board[2, 1] == 1) { label8.Text = "X"; } else { label8.Text = "O"; }
            if (board[2, 2] == 1) { label9.Text = "X"; } else { label9.Text = "O"; }
            #endregion

            // update textBoxResults.Text based on boardstate
            if (matchStatus == 0) { textBoxResults.Text = "Draw!"; }
            else if (matchStatus == 1) { textBoxResults.Text = "'O' Victory!"; }
            else if (matchStatus == 2) { textBoxResults.Text = "'X' Victory!"; }
        }

        /*Run the simulation again*/
        private void buttonNewGame_Click(object sender, EventArgs e)
        {
            populate();
            display();
            matchStatus = checkWin();
        }

        /*Exit the program*/
        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
