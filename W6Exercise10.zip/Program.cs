﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text.RegularExpressions;
using System.IO;
/* By Katon Bingham
 * 5/29/18
 * cs117
 */
namespace W6Exercise10
{
    class Program
    {
        // strip punctuation
        static string stripPunctuation(string item)
        {
            // remove specified punctuation
            item = item.Trim(new Char[] { ' ', '*', '.', '?', '!', ',' });

            return item;
        }

        static void Main(string[] args)
        {
            // read text file, split each word into its own line in a string array
            var file = File.ReadAllText(@"C:\Users\Katon Desktop\Documents\School\CST117\W6Exercise10\W6Exercise10\text.txt").Split(' ');

            int count = 0;
            foreach (var value in file)
            {
                string newstring;
                newstring = stripPunctuation(value);

                // check for words ending in 't' or 'e'
                if (System.Text.RegularExpressions.Regex.IsMatch(newstring, "[t, e]$"))
                { 
                    count++;
                }
            }

            // display the count
            Console.WriteLine("There are " + count + " words that end in t or e\n" + "Press any key to continue . . .");
            
            // pause at end of program
            Console.ReadKey();
        }
    }
}
